package com.example.hellotoastapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int mCount = 1; // Start with 1
    private TextView mShowCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mShowCount = findViewById(R.id.show_count);
        mShowCount.setText(String.valueOf(mCount)); // Set initial value to 1

        Button toastButton = findViewById(R.id.button_toast);
        toastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Complete the process", Toast.LENGTH_SHORT).show();
                mCount = 1; // Reset the count to 1
                mShowCount.setText(String.valueOf(mCount)); // Update the TextView to show 1
            }
        });

        Button countButton = findViewById(R.id.button_count);
        countButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCount == 1) {
                    mCount = 0; // Set count to 0 when button is clicked
                    mShowCount.setText(String.valueOf(mCount)); // Update the TextView to show 0
                }
            }
        });
    }
}
